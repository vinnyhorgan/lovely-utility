-- Import libraries
local nuklear = require "nuklear"
local log = require "libs/log"

-- Functions for filesystem operations
function exists(path)
  local ok, err, code = os.rename(path, path)

  if not ok then
	if code == 13 then
	  return true
	end
  end

  return ok
end

function getItems(path)
  local items = {}

  for item in io.popen("ls " .. path):lines() do
	table.insert(items, item)
  end

  return items
end

-- Utility functions
function getHead()
  local file = io.open(openProjectPath .. "/.vc/HEAD", "r")
  local head = file:read()
  file:close()

  return head
end

function updateHead(branch)
  local file = io.open(openProjectPath .. "/.vc/HEAD", "w+")
  file:write(branch)
  file:close()
end

function updateProjects()
  local updatedProjects = {}

  for line in io.lines(home .. "/.lvcprojects") do
	table.insert(updatedProjects, line)
  end

  projects = updatedProjects
end

function updateProjectsFile()
  local file = io.open(home .. "/.lvcprojects", "a")
  file:write(newProjectPath["value"] .. "\n")
  file:close()
end

function removeProject()
  local newList = {}

  for line in io.lines(home .. "/.lvcprojects") do
	if line ~= openProjectPath then
	  table.insert(newList, line)
	end
  end

  os.execute("rm " .. home .. "/.lvcprojects")
  os.execute("touch " .. home .. "/.lvcprojects")

  for k, v in pairs(newList) do
	local file = io.open(home .. "/.lvcprojects", "a")
	file:write(v)
	file:close()
  end
end

function updateCommits()
  local branch = getHead()
  openProjectCommits = getItems(openProjectPath .. "/.vc/branches/" .. branch)
end

function updateBranches()
  openProjectBranches = getItems(openProjectPath .. "/.vc/branches")
end

function initialize()
  if not exists(newProjectPath["value"] .. "/.vc") then
	os.execute("mkdir " .. newProjectPath["value"] ..  "/.vc")
	os.execute("mkdir " .. newProjectPath["value"] .. "/.vc/branches")
	os.execute("mkdir " .. newProjectPath["value"] .. "/.vc/branches/master")

	local file = io.open(newProjectPath["value"] .. "/.vc/HEAD", "w")
	file:write("master")
	file:close()
  end
end

-- Love2d callbacks
function love.load()
  -- Configure window
  love.window.setTitle("Lovely Version Control")
  love.window.setMode(400, 400)

  -- Get user home directory
  handle = io.popen("echo $HOME")
  home = handle:read("*a"):gsub("\n", "")

  -- Make sure the projects file exists
  if not exists(home .. "/.lvcprojects") then
	os.execute("touch " .. home .. "/.lvcprojects")
  end

  -- Initiate nuklear
  ui = nuklear.newUI()

  -- State variables
  projects = {}
  updateProjects()

  newProject = false
  newProjectPath = {value = ""}

  open = false
  openProjectPath = ""
  openProjectCommits = ""
  openProjectBranches = ""

  newBranch = false
  newBranchName = {value = ""}

  newCommit = false
  newCommitName = {value = ""}
  openCommitName = ""
end

function love.update(dt)
  ui:frameBegin()

  -- Left window, if a project is open it shows the commits and branches else it shows the projects list
  if open == false then
	if ui:windowBegin("Projects", 0, 0, 200, 400, "border", "title", "scrollbar", "scroll auto hide") then
	  ui:layoutRow("dynamic", 25, 1)

	  for k, v in pairs(projects) do
		path = v:gsub(home, "~")

		if ui:button(path) then
		  open = true
		  openProjectPath = v
		  updateCommits()
		  updateBranches()
		end
	  end
	end
	ui:windowEnd()
  else
	if ui:windowBegin("Commits", 0, 0, 200, 200, "border", "title", "scrollbar", "scroll auto hide") then
	  ui:layoutRow("dynamic", 25, 1)

	  for k, v in pairs(openProjectCommits) do
		name = v:gsub(".zip", "")

		if ui:button(name) then
		  openCommitName = name
		end
	  end
	end
	ui:windowEnd()

	if ui:windowBegin("Branches", 0, 200, 200, 200, "border", "title", "scrollbar", "scroll auto hide") then
	  ui:layoutRow("dynamic", 25, 1)

	  for k, v in pairs(openProjectBranches) do
		if ui:button(v) then
		  updateHead(v)
		  updateCommits()
		end
	  end
	end
	ui:windowEnd()
  end

  -- Right window, if a project is open it shows the project options, else it will show the main options
  if open == false then
	if ui:windowBegin("BaseActions", 200, 0, 200, 400, "border") then
	  ui:layoutRow("dynamic", 50, 1)
	  ui:spacing(2)

	  if newProject == false then
		if ui:button("New") then
		  newProject = true
		end
	  else
		ui:label("Path to Folder")
		ui:edit("simple", newProjectPath)
		isValidLocation = exists(newProjectPath["value"])

		if ui:button("Create") and newProjectPath["value"] ~= "" and isValidLocation == true then
		  initialize()
		  updateProjectsFile()
		  updateProjects()
		  newProjectPath["value"] = ""
		  newProject = false
		end

		if ui:button("Cancel") then
		  newProject = false
		end
	  end

	  ui:spacing(1)

	  if ui:button("Quit") then
		love.event.quit()
	  end
	end
	ui:windowEnd()
  else
	if ui:windowBegin("ProjectActions", 200, 0, 200, 400, "border") then
	  ui:layoutRow("dynamic", 40, 1)
	  ui:label("HEAD: " .. getHead() .. "\nCOMMIT: " .. openCommitName)
	  ui:spacing(1)

	  if newBranch == false then
		if ui:button("Create Branch") then
		  newBranch = true
		end
	  else
		ui:spacing(1)
		ui:label("Branch Name")
		ui:edit("simple", newBranchName)

		if ui:button("Create") and newBranchName["value"] ~= "" then
		  os.execute("mkdir " .. openProjectPath .. "/.vc/branches/" .. newBranchName["value"])
		  updateBranches()
		  updateCommits()
		  newBranchName["value"] = ""
		  newBranch = false
		end

		if ui:button("Cancel") then
		  newBranch = false
		end

		ui:spacing(1)
	  end

	  if newCommit == false then
		if ui:button("Create Commit") then
		  newCommit = true
		end
	  else
		ui:spacing(1)
		ui:label("Commit Name")
		ui:edit("simple", newCommitName)

		if ui:button("Commit") and newCommitName["value"] ~= "" then
		  branch = getHead()
		  os.execute("cd " .. openProjectPath .. " && mv .vc .. && zip -9 -r " .. newCommitName["value"] .. ".zip . > /dev/null && mv ../.vc . && mv " .. newCommitName["value"] .. ".zip ./.vc/branches/" .. branch)
		  updateCommits()
		  newCommitName["value"] = ""
		  newCommit = false
		end

		if ui:button("Cancel") then
		  newCommit = false
		end

		ui:spacing(1)
	  end

	  if ui:button("Revert") and openCommitName ~= "" then
		branch = getHead()
		os.execute("cd " .. openProjectPath .. " && mv .vc .. && rm -rf * && mv ../.vc . && cp ./.vc/branches/" .. branch .. "/" .. openCommitName .. ".zip . && unzip " .. openCommitName .. ".zip > /dev/null && rm " .. openCommitName .. ".zip")
	  end

	  if ui:button("Remove From List") then
		removeProject()
		updateProjects()
		open = false
	  end

	  if ui:button("Close") then
		open = false
	  end
	end
	ui:windowEnd()
  end

  ui:frameEnd()
end

function love.draw()
  ui:draw()
end

function love.keypressed(key, scancode, isrepeat)
  ui:keypressed(key, scancode, isrepeat)
end

function love.keyreleased(key, scancode)
  ui:keyreleased(key, scancode)
end

function love.mousepressed(x, y, button, istouch, presses)
  ui:mousepressed(x, y, button, istouch, presses)
end

function love.mousereleased(x, y, button, istouch, presses)
  ui:mousereleased(x, y, button, istouch, presses)
end

function love.mousemoved(x, y, dx, dy, istouch)
  ui:mousemoved(x, y, dx, dy, istouch)
end

function love.textinput(text)
  ui:textinput(text)
end

function love.wheelmoved(x, y)
  ui:wheelmoved(x, y)
end
